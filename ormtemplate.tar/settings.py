# PostgreSQL
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'postgres',
        'USER': 'postgres',
        'PASSWORD': 'Nzk4MS1zYXJhdGhm',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
INSTALLED_APPS = (
    'standalone',
)
SECRET_KEY = 'SECRET KEY for this Django Project'